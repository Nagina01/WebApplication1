const express = require('express');
const router = express.Router();

const data = require('../data/data.json');
router.get('/',  (req, res) => {
    res.render('venues', {
       content: 'Book Your venue with us',
        username: res.locals.booking
    });
});




module.exports = router;