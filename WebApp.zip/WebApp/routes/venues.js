const express = require('express');
const router = express.Router();

const data = require('../data/data.json');

router.get('/',  (req, res) => {
    res.render('venues', {
        title : 'venues',
       content: 'Find your perfect vanues',
       //users: venuesData,
        username: res.locals.venues
    });
});

router.post('update/:id', (req, res) => {
    res.redirect('/venues');
});

router.post('delete/:id', (req, res) => {
    res.redirect('/vunues');
});

router.get('/create/', (req, res) => {
    res.send('/venues');
});


router.post('create', (req, res) => {
    res.redirect('/venues');
});




module.exports = router;


